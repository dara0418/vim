<?php

class FooClass {

    public function bar() {
        $this->
        self::
    }
}

