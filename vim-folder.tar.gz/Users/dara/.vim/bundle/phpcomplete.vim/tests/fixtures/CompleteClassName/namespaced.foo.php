<?php
namespace NS1;

class NameSpacedFoo {

}
