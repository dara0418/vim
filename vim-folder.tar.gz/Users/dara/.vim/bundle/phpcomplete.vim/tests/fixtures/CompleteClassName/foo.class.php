<?php

class FooClass {
}

class BarClass {
}

