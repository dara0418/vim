<?php

$foo = FooClass::getInstance();
$foo->


$foo = RenamedFoo::getInstance();
$foo->
