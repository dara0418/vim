<?php
/* @var $bar FooClass */
$bar->

// @var $bar2 FooClass
$bar2->

// @var $bar3 Renamed
$bar3->
