<?php

$foo_only_in_tags->
$foo_only_in_tags::
