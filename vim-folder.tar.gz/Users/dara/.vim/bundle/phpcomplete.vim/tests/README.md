## Running the tests
Test are using the [vimunit plugin](https://github.com/dsummersl/vimunit), follow the [installation instructions](https://github.com/dsummersl/vimunit/blob/master/doc/vim_unit.txt).
Once you have it installed you can use it's `./vutest.sh` script to run the tests:

    cd ~/.vim/bundle/phpcomplete.vim/tests
    ~/.vim/bundle/vimunit/vutest.sh <test.vim file name>
    
