:orphan:

powerline-config manual page
============================

.. automan:: powerline.commands.config
   :prog: powerline-config

See also
--------

:manpage:`powerline(1)`
