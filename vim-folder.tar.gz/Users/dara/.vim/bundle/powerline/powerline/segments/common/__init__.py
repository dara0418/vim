# vim:fileencoding=utf-8:noet
from __future__ import (unicode_literals, division, absolute_import, print_function)


# DEPRECATED MODULE. Do not add any segments below. Do not remove existing 
# segments as well until next major release.


from powerline.segments.common.vcs import branch  # NOQA
from powerline.segments.common.sys import cpu_load_percent  # NOQA
from powerline.segments.common.sys import uptime  # NOQA
from powerline.segments.common.sys import system_load  # NOQA
from powerline.segments.common.net import hostname  # NOQA
from powerline.segments.common.net import external_ip  # NOQA
from powerline.segments.common.net import internal_ip  # NOQA
from powerline.segments.common.net import network_load  # NOQA
from powerline.segments.common.env import cwd  # NOQA
from powerline.segments.common.env import user  # NOQA
from powerline.segments.common.env import environment  # NOQA
from powerline.segments.common.env import virtualenv  # NOQA
from powerline.segments.common.bat import battery  # NOQA
from powerline.segments.common.wthr import weather  # NOQA
from powerline.segments.common.time import date  # NOQA
from powerline.segments.common.time import fuzzy_time  # NOQA
from powerline.segments.common.mail import email_imap_alert  # NOQA
from powerline.segments.common.players import now_playing  # NOQA
